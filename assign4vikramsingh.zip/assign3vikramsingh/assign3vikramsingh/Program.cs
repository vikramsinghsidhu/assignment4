﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assign3vikramsingh
{
    class Program
    {
        static void Main(string[] args)
       ques1/* { 
        string choose;
        again:
            Console.WriteLine("MENU:");
            Console.WriteLine("a.display list of even numbers beginning at 0");
            Console.WriteLine("b.display sequence of perfect squares");
            Console.WriteLine("c.exit");
            choose = Console.ReadLine();
            switch(choose)
            {
                case "a":
                    Console.WriteLine("number of even numbers to be displayed?");
                    string p = Console.ReadLine();
        int no = int.Parse(p);
                    for (int i = 0; i<=no; i++)
                    {
                        if (i % 2 == 0)
                        {
                            Console.WriteLine(i);
                        }
}
                    break;
                case "b":
                    int z = 1;
                    while (z >= 0)
                    {
                        int result = z * z;
                                Console.WriteLine(result);
                        Console.WriteLine("want to continue or return to main menu(c/m)");
                        string res = Console.ReadLine();
                        if(res=="c")
                        {
                            z++;
                            Console.WriteLine(result);
                        }
                        else
                        {
                            goto again;
                        }
                    }
                    break;
                case "c":break;
                   
                default:goto again;
            }*/


    ques2   /* {
            int number1;
            int number2;
            string operation;
            int answer;

            for (int i = 0; ; i++)
            {
                try
                {
                    Console.Write("enter the number 1 ; ");
                    number1 = Convert.ToInt32(Console.ReadLine());
                    Console.Write("enter the number 2  ;  ");
                    number2 = Convert.ToInt32(Console.ReadLine());
                    Console.Write("enter the operation(plus,minus,multiply,divide) ");
                    operation = Console.ReadLine();

                    if (operation == "multiply")
                    {
                        answer = number1 = number2;
                        Console.WriteLine(number1 + "x" + number2 + "=" + answer);
                    }



                    else if (operation == "divide")
                    {
                        answer = number1 / number2;
                        Console.WriteLine(number1 + "/" + number2 + "=" + answer);

                    }
                    else if (operation == "plus")
                    {
                        answer = number1 + number2;
                        Console.WriteLine(number1 + "+" + number2 + "=" + answer);

                    }
                    if (operation == "minus")
                    {
                        answer = number1 - number2;
                        Console.WriteLine(number1 + "-" + number2 + "=" + answer);

                    }
                    else
                    {
                        Console.WriteLine(" operation is incorrect");

                    }
                }
                catch (Exception)
                {
                    Console.WriteLine("enter valid value");

                }*/
            }
        }
    }
}
